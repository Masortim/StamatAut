﻿using StamatDB.Core;
using StamatDB.Models;
using System;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace StamatDB.Entities
{
    public class StamatEDM : DbContext
    {
        public StamatEDM() : base("StamatDB")
        {
            try
            {
                Database.SetInitializer(new CreateDatabaseIfNotExists<StamatEDM>());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public StamatEDM(string connectionString) : base(connectionString)
        {
            try
            {
                Database.SetInitializer(new CreateDatabaseIfNotExists<StamatEDM>());
                Database.SetInitializer(new DropCreateDatabaseIfModelChanges<StamatEDM>());
                Database.SetInitializer(new StamatDbInitializer());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            try
            {
                modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
                base.OnModelCreating(modelBuilder);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        // Отражение таблиц базы данных на свойства с типом DbSet
        public virtual DbSet<AdditionalPayments> AdditionalPayments { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Agregates> Agregates { get; set; }
        public virtual DbSet<AmortizationOfRepeirOnV> AmortizationOfRepeirOnV { get; set; }
        public virtual DbSet<Breaking> Breaking { get; set; }
        public virtual DbSet<ClassMachine> ClassMachine { get; set; }
        public virtual DbSet<Climate> Climate { get; set; }
        public virtual DbSet<CostsOfFertilizer> CostsOfFertilizer { get; set; }
        public virtual DbSet<Cultures> Cultures { get; set; }
        public virtual DbSet<Farm> Farm { get; set; }
        public virtual DbSet<FarmUser> FarmUser { get; set; }
        public virtual DbSet<Fertilizer> Fertilizer { get; set; }
        public virtual DbSet<GSMCosts> GSMCosts { get; set; }
        public virtual DbSet<Him> Him { get; set; }
        public virtual DbSet<HimCosts> HimCosts { get; set; }
        public virtual DbSet<Intensification> Intensification { get; set; }
        public virtual DbSet<KindOfFuel> KindOfFuel { get; set; }
        public virtual DbSet<KindOfWork> KindOfWork { get; set; }
        public virtual DbSet<Machinery> Machinery { get; set; }
        public virtual DbSet<Mechanizator> Mechanizator { get; set; }
        public virtual DbSet<MehMach> MehMach { get; set; }
        public virtual DbSet<OperationsOfAgrigate> OperationsOfAgrigate { get; set; }
        public virtual DbSet<Predshest> Predshest { get; set; }
        public virtual DbSet<SeedCosts> SeedCosts { get; set; }
        public virtual DbSet<SickList> SickList { get; set; }
        public virtual DbSet<StakesOfMech> StakesOfMech { get; set; }
        public virtual DbSet<StakesOfWorkers> StakesOfWorkers { get; set; }
        public virtual DbSet<TechKart> TechKart { get; set; }
        public virtual DbSet<TechnologicalOperations> TechnologicalOperations { get; set; }
        public virtual DbSet<TehAgro> TehAgro { get; set; }
        public virtual DbSet<TkPayments> TkPayments { get; set; }
        public virtual DbSet<TKR> TKR { get; set; }
        public virtual DbSet<Trailers> Trailers { get; set; }
        public virtual DbSet<TransportCosts> TransportCosts { get; set; }
        public virtual DbSet<WorkAreas> WorkAreas { get; set; }
        public virtual DbSet<WorkersLabourCosts> WorkersLabourCosts { get; set; }
    }
}
