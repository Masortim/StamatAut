﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class Cultures
    {
        public Cultures()
        {
            TKR = new HashSet<TKR>();
        }

        [Key]
        [ForeignKey("SeedCosts")]
        public int Id { get; set; }

        public string Name { get; set; }

        public float SeedingRase { get; set; }

        public float M1000 { get; set; }

        public float CountSeedOnGa { get; set; }

        public virtual ICollection<TKR> TKR { get; set; }

        public SeedCosts SeedCosts { get; set; }

    }
}
