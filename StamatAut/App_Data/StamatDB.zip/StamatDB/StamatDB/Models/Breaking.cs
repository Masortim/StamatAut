﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class Breaking
    {
        [Key]
        public int Id { get; set; }

        public DateTime DateBegin { get; set; }

        public DateTime DateEnd { get; set; }

        public string Reason { get; set; }

        //[ForeignKey("Machinery")]
        //public int MachineryId { get; set; }
        public virtual Machinery Machinery { get; set; }

    }
}
