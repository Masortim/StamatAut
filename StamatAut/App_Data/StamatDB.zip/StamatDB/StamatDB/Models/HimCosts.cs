﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class HimCosts
    {
        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public float CostOnUnit { get; set; }

        public float CostOnVWork { get; set; }

        public float CostsPrepAll { get; set; }

        public float CoeffApply { get; set; }

        public float Price { get; set; }

        public float CostsHimAll { get; set; }

        //[ForeignKey("Him")]
        //public int HimId { get; set; }
        public virtual Him Him { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }
        public virtual TechKart TechKart { get; set; }
    }

}

