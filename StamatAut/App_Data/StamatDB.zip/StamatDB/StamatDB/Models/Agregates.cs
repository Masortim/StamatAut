﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class Agregates
    {
        public Agregates()
        {
            TechKart = new HashSet<TechKart>();
            OperationsOfAgrigate = new HashSet<OperationsOfAgrigate>();
            ClassMachine = new HashSet<ClassMachine>();
            Trailers = new HashSet<Trailers>();
            KindOfFuel = new HashSet<KindOfFuel>();
        }

        [Key]
        public int Id { get; set; }

        [Required]
        //[MaxLength(15)]
        public string Name { get; set; }

        [Required]
        public int Count { get; set; }

        [Required]
        public float ShirZahvat { get; set; }

        public virtual ICollection<TechKart> TechKart { get; set; }

        public virtual ICollection<OperationsOfAgrigate> OperationsOfAgrigate { get; set; }

        public virtual ICollection<ClassMachine> ClassMachine { get; set; }

        public virtual ICollection<Trailers> Trailers { get; set; }

        public virtual ICollection<KindOfFuel> KindOfFuel { get; set; }

        //[ForeignKey("Farm")]
        //public int FarmId { get; set; }
        public virtual Farm Farm { get; set; }
    }
}
