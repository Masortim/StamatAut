﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class Him
    {
        public Him()
        {
            HimCosts = new HashSet<HimCosts>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Unit { get; set; }

        public ICollection<HimCosts> HimCosts { get; set; }
    }
}
