﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class GSMCosts
    {
        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public float CostFuelAll { get; set; }

        public float CostAll { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }
        public virtual TechKart TechKart { get; set; }
    }
}
