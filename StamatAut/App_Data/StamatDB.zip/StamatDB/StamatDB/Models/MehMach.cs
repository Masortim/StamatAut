﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class MehMach
    {
        public MehMach()
        {
            Machinery = new HashSet<Machinery>();
            Mechanizator = new HashSet<Mechanizator>();
        }

        [Key]
        public int Id { get; set; }

        public virtual ICollection<Machinery> Machinery { get; set; }

        public virtual ICollection<Mechanizator> Mechanizator { get; set; }
    }
}
