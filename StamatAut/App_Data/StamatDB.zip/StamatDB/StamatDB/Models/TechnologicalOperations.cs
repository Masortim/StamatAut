﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class TechnologicalOperations
    {
        public TechnologicalOperations()
        {
            Climate = new HashSet<Climate>();
        }

        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public string KodOperation { get; set; }

        public string Name { get; set; }

        public string Parametrs { get; set; }

        public string Annotation { get; set; }

        public string Application { get; set; }

        public string Unit { get; set; }

        public int Rang { get; set; }

        public virtual TechKart TechKart { get; set; }

        //[ForeignKey("KindOfWork")]
        //public int KindOfWorkId { get; set; }
        public virtual KindOfWork KindOfWork { get; set; }

        public virtual ICollection<Climate> Climate { get; set; }

    }
}
