﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class WorkAreas
    {
        public WorkAreas()
        {
            TechKart = new HashSet<TechKart>();
        }

        [Key]
        public int Id { get; set; }

        [Required]
        public string NumUch { get; set; }

        [Required]
        public float Square { get; set; }

        [Required]
        public float MaxShirZahv { get; set; }

        public virtual ICollection<TechKart> TechKart { get; set; }
    }
}
