﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class SickList
    {
        [Key]
        public int Id { get; set; }

        public DateTime DateBegin { get; set; }

        public DateTime DateEnd { get; set; }

        public string Reason { get; set; }

        //[ForeignKey("Mechanizator")]
       // public int MechanizatorId { get; set; }
        public virtual Mechanizator Mechanizator { get; set; }
    }
}
