﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class AdditionalPayments
    {
        public AdditionalPayments()
        {

        }

        [Key]
        public int Id { get; set; }

        [Required]
        //[MaxLength(15)]
        public string Name { get; set; }

        [Required]
        public float Value { get; set; }

        //[ForeignKey("Farm")]
        //public int FarmId { get; set; }
        public virtual Farm Farm { get; set; }

        //[ForeignKey("TkPayments")]
        //public int TkPaymentsId { get; set; }
        public virtual TkPayments TkPayments { get; set; }
    }
}
