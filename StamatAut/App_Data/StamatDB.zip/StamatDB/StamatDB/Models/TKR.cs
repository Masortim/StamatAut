﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class TKR
    {
        public TKR()
        {
            TechKart = new HashSet<TechKart>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public int YearCrop { get; set; }

        public string Others { get; set; }

       // [ForeignKey("Cultures")]
        //public int CulturesId { get; set; }
        public virtual Cultures Cultures { get; set; }

        public virtual ICollection<TechKart> TechKart { get; set; }

        //[ForeignKey("Farm")]
        //public int FarmId { get; set; }
        public virtual Farm Farm { get; set; }

        //[ForeignKey("Predshest")]
        //public int PredshestId { get; set; }
        public virtual Predshest Predshest { get; set; }

        //[ForeignKey("Intensification")]
        //public int IntensificationId { get; set; }
        public virtual Intensification Intensification { get; set; }
    }
}
