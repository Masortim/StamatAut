﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class TechKart
    {
        [Key]
        public int Id { get; set; }

        public DateTime DateBegin { get; set; }

        public DateTime DateEnd { get; set; }

        public float AmmountOfWorks { get; set; }

        public float PercentOfWorksOnThis { get; set; }

        public float CountOfNormSm { get; set; }

        public float CostLaborOnWork { get; set; }

        public float CostGSMOnWork { get; set; }

        public float CostOfTransport { get; set; }

        public float CostOfSeeds { get; set; }

        public float CostOfChem { get; set; }

        public float CostOfFertiliz { get; set; }

        public float GeneralCosts { get; set; }

        public int ChasSm { get; set; }

        public int ClassOfMeh { get; set; }

        public int CountOfMeh { get; set; }

        public int ClassOfWorker { get; set; }

        public int CountOfWorker { get; set; }

        public virtual TransportCosts TransportCosts { get; set; }

        public virtual GSMCosts GSMCosts { get; set; }

        public virtual CostsOfFertilizer CostsOfFertilizer { get; set; }

        public virtual HimCosts HimCosts { get; set; }

        public virtual WorkersLabourCosts WorkersLabourCosts { get; set; }

        public virtual SeedCosts SeedCosts { get; set; }

        //[ForeignKey("AmortizationOfRepeirOnV")]
        //public int AmortizationOfRepeirOnVId { get; set; }
        public AmortizationOfRepeirOnV AmortizationOfRepeirOnV { get; set; }

        //[ForeignKey("TKR")]
        //public int TKRId { get; set; }
        public virtual TKR TKR { get; set; }

        //[ForeignKey("WorkAreas")]
        //public int WorkAreasId { get; set; }
        public virtual WorkAreas WorkAreas { get; set; }

        //[ForeignKey("TkPayments")]
        //public int TkPaymentsId { get; set; }
        public virtual TkPayments TkPayments { get; set; }

        //[ForeignKey("Agregates")]
        //public int AgregatesId { get; set; }
        public virtual Agregates Agregates { get; set; }

        //[ForeignKey("Machinery")]
        //public int MachineryId { get; set; }
        public virtual Machinery Machinery { get; set; }

        //[ForeignKey("TechnologicalOperations")]
        //public int TechnologicalOperationsId { get; set; }
        public virtual TechnologicalOperations TechnologicalOperations { get; set; }

        //[ForeignKey("Mechanizator")]
        //public int MechanizatorId { get; set; }
        public virtual Mechanizator Mechanizator { get; set; }

        //[ForeignKey("StakesOfWorkers")]
        //public int StakesOfWorkersId { get; set; }
        public virtual StakesOfWorkers StakesOfWorkers { get; set; }

    }
}
