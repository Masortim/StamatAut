﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class Intensification
    {
        public Intensification()
        {
            TKR = new HashSet<TKR>();
        }

        [Key]
        public int Id { get; set; }

        public string Level_Int { get; set; }

        public virtual ICollection<TKR> TKR { get; set; }
    }
}
