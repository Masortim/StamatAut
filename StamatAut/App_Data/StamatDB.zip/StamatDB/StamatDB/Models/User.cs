﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class User
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Password { get; set; }

        public int AccesLevel { get; set; }

        //[ForeignKey("FarmUser")]
        //public int FarmUserId { get; set; }
        public virtual FarmUser FarmUser { get; set; }
    }
}
