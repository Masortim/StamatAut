﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class Trailers
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public float Price { get; set; }

        public float NormZagruz { get; set; }

        public float PersentAmortOfTO { get; set; }

        public int Count { get; set; }

        public float PercentAmort { get; set; }

        //[ForeignKey("Farm")]
        //public int FarmId { get; set; }
        public virtual Farm Farm { get; set; }

        //[ForeignKey("Agregates")]
       // public int AgregatesId { get; set; }
        public virtual Agregates Agregates { get; set; }
    }
}
