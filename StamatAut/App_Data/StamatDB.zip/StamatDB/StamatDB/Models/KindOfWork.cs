﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace StamatDB.Models
{
    public partial class KindOfWork
    {
        public KindOfWork()
        {
            TechnologicalOperations = new HashSet<TechnologicalOperations>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public virtual ICollection<TechnologicalOperations> TechnologicalOperations { get; set; }

    }
}
