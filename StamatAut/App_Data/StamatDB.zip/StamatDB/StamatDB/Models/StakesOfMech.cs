﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class StakesOfMech
    {
        public StakesOfMech()
        {
            Mechanizator = new HashSet<Mechanizator>();
        }

        [Key]
        public int Id { get; set; }

        public float Stake { get; set; }

        public int Rank { get; set; }

        public virtual ICollection<Mechanizator> Mechanizator { get; set; }
    }
}
