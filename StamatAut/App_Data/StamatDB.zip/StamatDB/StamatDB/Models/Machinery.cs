﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class Machinery
    {
        public Machinery()
        {
            TechKart = new HashSet<TechKart>();
            Breaking = new HashSet<Breaking>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Type { get; set; }

        public float Price { get; set; }

        public string Kind { get; set; }

        public string SerialNumber { get; set; }

        public int NormZagruz { get; set; }

        public float PersentAmortOfTO { get; set; }

        public float PercentAmort { get; set; }

        public virtual ICollection<TechKart> TechKart { get; set; }

        public virtual ICollection<Breaking> Breaking { get; set; }

        //[ForeignKey("Farm")]
        //public int FarmId { get; set; }
        public virtual Farm Farm { get; set; }

        //[ForeignKey("ClassMachine")]
        //public int ClassMachineId { get; set; }
        public virtual ClassMachine ClassMachine { get; set; }

        //[ForeignKey("MehMach")]
        //public int MehMachId { get; set; }
        public virtual MehMach MehMach { get; set; }

    }
}
