﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class TkPayments
    {
        public TkPayments()
        {
            TechKart = new HashSet<TechKart>();
            AdditionalPayments = new HashSet<AdditionalPayments>();
        }

        [Key]
        public int Id { get; set; }

        public virtual ICollection<TechKart> TechKart { get; set; }

        public virtual ICollection<AdditionalPayments> AdditionalPayments { get; set; }
    }
}
