﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class OperationsOfAgrigate
    {
        [Key]
        public int Id { get; set; }

        public float SeedingRate { get; set; }

        public float GSMCharge { get; set; }

        //[ForeignKey("Agregates")]
        //public int AgregatesId { get; set; }
        public virtual Agregates Agregates { get; set; }
    }
}
