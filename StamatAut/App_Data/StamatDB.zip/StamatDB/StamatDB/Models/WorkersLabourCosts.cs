﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class WorkersLabourCosts
    {
        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        [Required]
        public float LabourInputsM { get; set; }

        [Required]
        public float LabourInputsW { get; set; }

        [Required]
        public float LabourInputsAll { get; set; }

        [Required]
        public float TfLabourM { get; set; }

        [Required]
        public float TfLabourW { get; set; }

        [Required]
        public float TfLabourAll { get; set; }

        [Required]
        public float TfPayment { get; set; }

        [Required]
        public float TaxAndPayment { get; set; }

        [Required]
        public float TariffRateM { get; set; }

        [Required]
        public float TariffRateW { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }
        public virtual TechKart TechKart { get; set; }
    }
}
