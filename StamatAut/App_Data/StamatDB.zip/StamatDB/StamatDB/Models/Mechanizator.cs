﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class Mechanizator
    {
        public Mechanizator()
        {
            SickList = new HashSet<SickList>();
        }

        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Class { get; set; }

        public virtual TechKart TechKart { get; set; }

        //[ForeignKey("MehMach")]
        //public int MehMachId { get; set; }
        public virtual MehMach MehMach { get; set; }

        //[ForeignKey("StakesOfMech")]
        //public int StakesOfMechId { get; set; }
        public virtual StakesOfMech StakesOfMech { get; set; }

        public virtual ICollection<SickList> SickList { get; set; }
    }
}
