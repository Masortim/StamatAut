﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class TransportCosts
    {
        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public float DistanceKm { get; set; }

        public float SeedsTKm { get; set; }

        public float SupplyUdoWaterTKm { get; set; }

        public float CostUnit { get; set; }

        public float CostAll { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }
        public virtual TechKart TechKart { get; set; }
    }
}
