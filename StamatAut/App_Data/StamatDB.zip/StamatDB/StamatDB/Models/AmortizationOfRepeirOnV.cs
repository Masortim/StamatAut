﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class AmortizationOfRepeirOnV
    {
        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public float TOAndRepair { get; set; }

        public float AmmortOfMachineryOnV { get; set; }

        public float AmmortOfTrailerOnV { get; set; }

        public float All { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }

        [Required]
        public TechKart TechKart { get; set; }
    }
}
