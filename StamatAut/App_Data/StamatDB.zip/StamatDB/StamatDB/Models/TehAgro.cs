﻿using System;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class TehAgro
    {
        [Key]
        public int Id { get; set; }

        public DateTime DateBegin { get; set; }

        public DateTime DateEnd { get; set; }

        public int ChasSm { get; set; }

        public float Rast { get; set; }

        public float StoimPodv { get; set; }

        public float StoimS { get; set; }

        public int RankWorker { get; set; }

        public int KolWorker { get; set; }

        public string PovOPl { get; set; }

        public int ThisH { get; set; }

        public float RashHim { get; set; }

        public float StoimHim { get; set; }

        public float Koef { get; set; }

        public int ThisF { get; set; }

        public string FlgUpak { get; set; }

        public float URash { get; set; }

        public float VUpak { get; set; }

        public float StoimUpak { get; set; }


    }
}
