﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class FarmUser
    {
        public FarmUser()
        {
            User = new HashSet<User>();
        }

        [Key]
        [ForeignKey("Farm")]
        public int Id { get; set; }        

        public virtual ICollection<User> User { get; set; }

        //[ForeignKey("Farm")]
        //public int FarmId { get; set; }
        public virtual Farm Farm { get; set; }
    }
}
