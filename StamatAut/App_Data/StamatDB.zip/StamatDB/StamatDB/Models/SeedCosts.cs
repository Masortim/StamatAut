﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class SeedCosts
    {
        [Key]
        [ForeignKey("TechKart")]        
        public int Id { get; set; }

        public float CountOfSeeds { get; set; }

        public float Price { get; set; }

        public float CostAll { get; set; }

        //[ForeignKey("Cultures")]
        //public int CulturesId { get; set; }
        public virtual Cultures Cultures { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }
        public virtual TechKart TechKart { get; set; }
    }
}
