﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class Farm
    {
        public Farm()
        {
            TKR = new HashSet<TKR>();
            Agregates = new HashSet<Agregates>();
            Machinery = new HashSet<Machinery>();
            AdditionalPayments = new HashSet<AdditionalPayments>();
            Trailers = new HashSet<Trailers>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public virtual FarmUser FarmUser { get; set; }

        public virtual ICollection<TKR> TKR { get; set; }

        public virtual ICollection<Agregates> Agregates { get; set; }

        public virtual ICollection<Machinery> Machinery { get; set; }

        public virtual ICollection<AdditionalPayments> AdditionalPayments { get; set; }

        public virtual ICollection<Trailers> Trailers { get; set; }

    }
}
