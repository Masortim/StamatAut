﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class Fertilizer
    {
        public Fertilizer()
        {
            CostsOfFertilizer = new HashSet<CostsOfFertilizer>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Unit { get; set; }

        public string ContentOfPrep { get; set; }

        public int Reactant { get; set; }

        public ICollection<CostsOfFertilizer> CostsOfFertilizer { get; set; }
    }
}
