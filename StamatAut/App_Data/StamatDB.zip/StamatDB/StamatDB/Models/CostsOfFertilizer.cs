﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StamatDB.Models
{
    public partial class CostsOfFertilizer
    {
        [Key]
        [ForeignKey("TechKart")]
        public int Id { get; set; }

        public int CountOfFertilizer { get; set; }

        public float ExpensisOn1V { get; set; }

        public float ExpensisOn1W { get; set; }

        public float Price { get; set; }

        public float CostsAll { get; set; }

        public float VUpak { get; set; }

        public int FlgUpak { get; set; }

        //[ForeignKey("Fertilizer")]
       // public int FertilizerId { get; set; }
        public virtual Fertilizer Fertilizer { get; set; }

        //[ForeignKey("TechKart")]
        //public int TechKartId { get; set; }
        public virtual TechKart TechKart { get; set; }
    }
}
