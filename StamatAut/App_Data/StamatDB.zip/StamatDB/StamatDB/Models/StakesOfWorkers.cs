﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class StakesOfWorkers
    {
        public StakesOfWorkers()
        {
            TechKart = new HashSet<TechKart>();
        }

        [Key]
        public int Id { get; set; }

        public float Stake { get; set; }

        public int Rank { get; set; }

        public virtual ICollection<TechKart> TechKart { get; set; }

    }
}
