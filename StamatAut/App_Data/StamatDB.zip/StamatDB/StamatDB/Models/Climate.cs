﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StamatDB.Models
{
    public partial class Climate
    {
        public Climate()
        {
            TechnologicalOperations = new HashSet<TechnologicalOperations>();
        }

        [Key]
        public int Id { get; set; }

        public float Name { get; set; }

        public float SummTempVegPer { get; set; }

        public float KolOsadkov { get; set; }

        public DateTime DataBVegPer { get; set; }

        public DateTime DataEVegPer { get; set; }

        public string KolOsad { get; set; }

        public virtual ICollection<TechnologicalOperations> TechnologicalOperations { get; set; }

    }
}
