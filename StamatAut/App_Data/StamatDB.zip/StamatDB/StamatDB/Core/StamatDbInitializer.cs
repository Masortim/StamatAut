﻿using StamatDB.Entities;
using System;
using System.Data.Entity;

namespace StamatDB.Core
{
    class StamatDbInitializer : DropCreateDatabaseIfModelChanges<StamatEDM>
    {
        protected override void Seed(StamatEDM context)
        {
            try
            {
                context.User.Add(new Models.User
                {
                    Name = "test",
                    Password = "123456789"
                });


                base.Seed(context);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
