﻿using StamatDB.Entities;
using StamatDB.Models;
using System;
using System.Collections.ObjectModel;
using System.Data.Entity;

namespace StamatDB.Core
{
    public class DBRepository
    {
        #region Variables        

        private static StamatEDM _stamatDbContext;

        #endregion

        #region Ctor

        public DBRepository()
        {
            _stamatDbContext = new StamatEDM(GetConnectionString("StamatDB"));            

            try
            {
                _stamatDbContext.AdditionalPayments.Load();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                //throw new Exception(ex.Message);
            }
        }

        #endregion

        #region ConnectionString

        private string GetConnectionString(string dbName)
        {
            var str = string.Empty;
            str = 
                "data source=(LocalDB)\\MSSQLLocalDB;" +
                "Initial Catalog=" + dbName + ";" +
                "AttachDBFilename=" + Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData).ToString() + "\\SibFTI\\" + dbName + ".mdf;" +
                "Integrated security=True;" +
                "Connection Timeout=30;" +
                "MultipleActiveResultSets=True;" +
                "App=EntityFramework;";

            return str;
        }

        #endregion

        #region Clients

        public static ObservableCollection<AdditionalPayments> GetClients()
        {
            try
            {
                _stamatDbContext.AdditionalPayments.Load();
                return _stamatDbContext.AdditionalPayments.Local;
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
            {                
                throw new Exception(ex.InnerException.InnerException.ToString());                
            }
        }

        #endregion
    }
}
